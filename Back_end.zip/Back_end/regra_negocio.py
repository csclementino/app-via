import banco
from datetime import datetime

def logar_usuario(email,senha):
    usuario = banco.recuperar_usuario(email)
    if usuario is not None:
        if usuario[2] == senha:
            return {"sucesso": True, "usuario": usuario[0]}
        else: return{"erro": "Senha inválida"}
    else: return{"erro": "E-mail inválido"}

def cadastrar_usuario(nome,email,senha,data_nascimento):
    usuario = banco.recuperar_usuario(email)
    if usuario is not None:
        return{"erro": "Este E-mail já possuí cadastro conosco!"}
    else:
        msg = banco.inserir_usuario(nome,email,senha,data_nascimento)
        return {"sucesso": True, "mensagem": msg}
    
def buscar_usuario(id_user):
    usuario = banco.buscar_user(id_user)
    if usuario is not None:
        return {"sucesso": True, "dados_user": usuario}
    return {"erro": "Usuario não encontrado"}

def alterar_usuario(id_user,nome,email,senha,data_nascimento):
    msg = banco.alterar_user(id_user,nome,email,senha,data_nascimento)
    return msg

def logar_admin(username,senha):
    usuario = banco.recuperar_admin(username)
    if usuario is not None:
        if usuario[0] == senha:
            return {"sucesso": True, "id_cco": usuario[1],"nome_cco": usuario[2]}
        else: return{"error": "Senha incorreta!"}
    else: return{"error": "Username incorreto!"}

def buscar_reportes(id_linha):
    reportes = banco.buscar_reportes(id_linha)
    if reportes is not None:
        for item in reportes:
            data_str = item.get("data_criacao")
            if data_str:
                 item["data_criacao"] = data_str.strftime("%d/%m/%Y %H:%M")
        return {"sucesso": True, "dados_reportes": reportes}
    return {"erro": "Linha incorreta"}

def buscar_reporte(id_reporte):
    reporte = banco.buscar_reporte(id_reporte)
    if reporte is not None:
        data_str = reporte.get("data_criacao")
        if data_str:
            reporte["data_criacao"] = data_str.strftime("%d/%m/%Y %H:%M")
        data_str = reporte.get("data_ocorrencia")
        if data_str:
            reporte["data_ocorrencia"] = data_str.strftime("%d/%m/%Y")
        return {"sucesso": True, "dado_reporte": reporte}
    return {"erro": "Reporte incorreto"}

def marcar_analisado(id_reporte,analisado):
    msg = banco.marcar_analisado(id_reporte,analisado)
    return {"sucesso": True, "msg": msg}

def buscar_historico(id_linha):
    reportes = banco.buscar_historico(id_linha)
    if reportes is not None:
        for item in reportes:
            data_str = item.get("data_criacao")
            if data_str:
                 item["data_criacao"] = data_str.strftime("%d/%m/%Y %H:%M")
        return {"sucesso": True, "dados_reportes": reportes}

def buscar_overview(id_linha):
    reportes_recentes = banco.reportes_recentes(id_linha)
    reportes_solucionados = banco.reportes_solucionados(id_linha)
    mais_reportados = banco.mais_reportados(id_linha)
    estacao = banco.estacao_reportes(id_linha)
    return {"sucesso": True, "overview": {"recentes": reportes_recentes,"solucionados":reportes_solucionados,"mais_reportado":mais_reportados,"estacao":estacao}}