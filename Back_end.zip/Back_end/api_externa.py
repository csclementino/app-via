from fastapi import FastAPI, Request, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from datetime import datetime
from fastapi.responses import JSONResponse
import pytz
import httpx
import regra_negocio

app = FastAPI()
# CORS para permitir acesso do React ou outro frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Altere conforme necessário
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/api/next-train/{departure}/{linha}/{estacao}")
async def pegar_info_estacao(linha: str, estacao: str, departure: str):
    url_externa = f"https://apim-appsitemobilidade-prd-brazilsouth-001.azure-api.net/int/ccr/next-train/concessionaire/{departure}/track/{linha}/departure/{estacao}"
    headers = {
        "accept": "application/json, text/plain, */*",
        "apim-api-key": "8b197e2fd3ed4508b8f0bbb695d9b08f",
        "Host": "apim-appsitemobilidade-prd-brazilsouth-001.azure-api.net",
        "Connection": "Keep-Alive",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.9"
    }
    async with httpx.AsyncClient() as client:
        resposta = await client.get(url_externa, headers=headers)

    if resposta.status_code == 200:
        fuso_brasilia = pytz.timezone("America/Sao_Paulo")
        agora = datetime.now(fuso_brasilia)
        dados = resposta.json()
        dados["ultima_atualizacao"] = agora.strftime("%d/%m/%Y %H:%M")
        return dados
    else:
        return {
            "erro": "Não foi possível obter informações da API externa",
            "status_code": resposta.status_code,
            "detalhes": resposta.text
        }


@app.get("/api/linhas")
async def status_linha():
    url_externa = "https://webapi.grupoccr.com.br/v1/mobility/public/line-status/current/state/SP"
    linha_data = {
        "dados_trem": {}
    }
    async with httpx.AsyncClient() as client:
        resposta = await client.get(url_externa)
    if resposta.status_code == 200:
        linha_data["dados_trem"] = resposta.json()
        linhas = {}
        fuso_brasilia = pytz.timezone("America/Sao_Paulo")
        agora = datetime.now(fuso_brasilia)
        linhas["ultima_atualizacao"] = agora.strftime("%d/%m/%Y %H:%M")
        for concessao in linha_data["dados_trem"]["data"]["concessoes"]:
            for linha in concessao["linhas"]:
                numero = linha["numero"]
                status = linha["statusLinha"]["status"]
                descricao = linha["statusLinha"]["descricao"]

                linhas[f"linha{numero}"] = {
                    "status": status,
                    "descricao": descricao
                }
        return linhas
    else:
        return {
            "erro": "Não foi possível obter informações da API externa",
            "status_code": resposta.status_code,
            "detalhes": resposta.text
        }
    
@app.post("/api/login-usuario")
async def login_usuario(request: Request):
    body = await request.json()
    email = body.get("email")
    senha = body.get("senha")
    try:
        return regra_negocio.logar_usuario(email,senha)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")

@app.post("/api/cadastrar-usuario")
async def cadastrar_usuario(request: Request):
    body = await request.json()
    nome = body.get("nome")
    email = body.get("email")
    senha = body.get("senha")
    data_nascimento_str = body.get("data_nascimento") 
    if not nome or not email or not senha or not data_nascimento_str:
        raise HTTPException(status_code=400, detail="Todos os campos são obrigatórios.")
    try:
        data_nascimento = datetime.strptime(data_nascimento_str, "%d/%m/%Y").date()
        return regra_negocio.cadastrar_usuario(nome,email,senha,data_nascimento)
    except ValueError:
        raise HTTPException(status_code=400, detail="Formato de data inválido. Use dd/mm/aaaa.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao cadastrar: {str(e)}")

@app.get("/api/buscar-usuario/{id_user}")
async def login_usuario(id_user: str):
    try:
        return regra_negocio.buscar_usuario(id_user)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")
    
@app.post("/api/alterar-usuario")
async def cadastrar_usuario(request: Request):
    body = await request.json()
    id_user = body.get("id_user")
    nome = body.get("nome")
    email = body.get("email")
    senha = body.get("senha")
    data_nascimento = body.get("data_nascimento") 
    if not nome or not email or not senha or not data_nascimento:
        raise HTTPException(status_code=400, detail="Todos os campos são obrigatórios.")
    try:
        return regra_negocio.alterar_usuario(id_user,nome,email,senha,data_nascimento)
    except ValueError:
        raise HTTPException(status_code=400, detail="Formato de data inválido. Use dd/mm/aaaa.")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao cadastrar: {str(e)}")
    
@app.post("/api/admin")
async def login_admin(request: Request):
    body = await request.json()
    username = body.get("username")
    senha = body.get("password")
    try:
        return regra_negocio.logar_admin(username,senha)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")
    
@app.get("/api/admin/reportes/line/{linha}")
async def buscar_reportes(linha: str):
    try:
        return regra_negocio.buscar_reportes(linha)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")
    
@app.get("/api/admin/reportes/{reporte}")
async def busca_reporte(reporte: int):
    try:
        return regra_negocio.buscar_reporte(reporte)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")
    
@app.put("/api/admin/reportes/analisar")
async def marcar_analisado(request: Request):
    body = await request.json()
    id_reporte = body.get("id_reporte")
    analisado = body.get("analisado")
    try:
        return regra_negocio.marcar_analisado(id_reporte,analisado)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")


@app.get("/api/admin/historico/line/{linha}")
async def buscar_historico(linha: str):
    try:
        return regra_negocio.buscar_historico(linha)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")


@app.get("/api/admin/overview/line/{linha}")
async def buscar_overview(linha: str):
    try:
        return regra_negocio.buscar_overview(linha)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro no servidor: {str(e)}")