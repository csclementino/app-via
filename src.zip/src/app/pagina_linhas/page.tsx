// app/tela_principal/page.tsx
'use client'

import React from 'react';
import Navegacao from '@/components/barra_navegacao/page';
import LinhasStatus from '@/components/conteudo_linhas/page';

const PaginaLinhas = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-1 flex flex-col">
        <div className="relative pb-20 flex-1">      
          <LinhasStatus />
        </div>
      </div>

      <Navegacao />
    </div>
  );
};

export default PaginaLinhas;