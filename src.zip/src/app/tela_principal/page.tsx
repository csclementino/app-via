// app/tela_principal/page.tsx
'use client'

import React from 'react';
import Header_Principal from '@/components/header_principal/page';
import Navegacao from '@/components/barra_navegacao/page';
import { Parceiros } from '@/components/parceiros/page'
import { AcessoRapido } from '@/components/acessoRapido/page';

const MainPage = () => {
  const buttons = [
    {
      texto: "Próximo trem",
      icone: "prox_trem.png",
      caminho: "/proximo-trem" // Caminho da página
    },
    {
      texto: "Status linha",
      icone: "status_linha.png",
      caminho: "/pagina_linhas" // Caminho corrigido
    },
    {
      texto: "Reportes",
      icone: "reporte.png",
      caminho: "/reportes" // Novo caminho
    }
  ];

  const parceirosData = [
    {
      caminho: "logo_arc.png",
      titulo: "Arc Group",
      texto: "Startup de tecnologia \nfocada em inovação.",
      link: "#"
    },
    {
      caminho: "fiap.png",
      titulo: "Fiap",
      texto: "Faculdade referência \nem tecnologia.",
      link: "#"
    },
    {
      caminho: "motiva.png",
      titulo: "Motiva",
      texto: "Operadora e gestora \ndas linhas.",
      link: "#"
    },
  ];

  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-1 flex flex-col">
        <Header_Principal />

        <div className="relative pb-20 mb-16 flex-1">
          <AcessoRapido
            titulo="Acesso rápido"
            botoes={buttons}
          />
          
          <section className="mt-8">
            <Parceiros titulo="Parceiros" parceiros={parceirosData} />
          </section>
        </div>
      </div>

      <Navegacao />
    </div>
  );
};

export default MainPage;