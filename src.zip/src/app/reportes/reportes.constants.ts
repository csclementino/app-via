export const categories = [
  'Assedio',
  'Racismo', 
  'Roubo',
  'Vandalismo',
  'Violência',
  'Venda Ilegal'
] as const;

export type ReportCategory = typeof categories[number];

export const categoryIcons: Record<ReportCategory, string> = {
  'Assedio': 'assedio.png',
  'Racismo': 'racismo.png',
  'Roubo': 'roubo.png',
  'Vandalismo': 'vandalismo.png',
  'Violência': 'violencia.png',
  'Venda Ilegal': 'vendedor.png'
};

export const categorySlugs = categories.map(category => ({
  tipo: category.toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/ /g, '-')
}));