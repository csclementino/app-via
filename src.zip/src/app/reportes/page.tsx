'use client';
import React from 'react';
import { ReportHeader } from '@/components/ReportHeader/page';
import Navegacao from '@/components/barra_navegacao/page';
import Image from 'next/image';
import Link from 'next/link';
import { categories, categoryIcons } from './reportes.constants';

const ReportesPage = () => {
  return (
    <div className="min-h-screen">
      <ReportHeader />

      <main className="max-w-4xl mx-auto px-4 py-8">
        <section className="mb-12">
          <h2 className="text-2xl font-semibold text-white mb-6">
            Escolha o que deseja reportar
          </h2>
          <div className="grid grid-cols-3 gap-4">
            {categories.map((category) => (
              <Link
                key={category}
                href={`/reportes/${category.toLowerCase().replace(' ', '-')}`}
                className="bg-neutral-600 rounded-4xl shadow-md hover:bg-neutral-500 transition-colors"
              >
                <div className="flex flex-col items-center w-full h-full p-5">
                  <div className="p-2">
                    <Image
                      src={categoryIcons[category]}
                      alt={category}
                      width={40}
                      height={40}
                    />
                  </div>
                  <span className="text-white text-xs font-medium">{category}</span>
                </div>
              </Link>
            ))}
          </div>
        </section>

        <div className="border border-white rounded-2xl px-4 p-2 mb-25">
          <Link href="/meus_reportes">
            <div className="flex justify-between items-center w-full text-white hover:text-gray-300 cursor-pointer transition-colors">
              <span className="text-lg font-medium ml-4">Meus Reportes</span>
              <span className="text-xl">&gt;</span>
            </div>
          </Link>
        </div>

        <Navegacao />
      </main>
    </div>
  );
};

export default ReportesPage;