import { categorySlugs } from '../reportes.constants';
import { CadastroReporteForm } from '@/components/CadastroReporteForm/page';
import { Suspense } from 'react';

export function generateStaticParams() {
  return categorySlugs;
}

export default function Page({ params }: { params: { tipo: string } }) {
  return (
    <Suspense fallback={<div>Carregando...</div>}>
      <CadastroReporteForm tipoReporte={params.tipo} />
    </Suspense>
  );
}