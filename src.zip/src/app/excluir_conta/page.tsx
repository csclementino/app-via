// app/tela_excluir_conta/page.tsx
'use client'

import Link from 'next/link';

const DeleteAccountScreen = () => {
  const handleDeleteAccount = () => {
    console.log('Conta excluída');
  };

  return (
    <main className="min-h-screen flex flex-col items-center p-8 text-center">

      <div className="max-w-3xl w-full px-4 py-8">
        <h1 className="text-3xl font-bold text-white mb-6">
          Tem certeza que deseja excluir sua conta?
        </h1>
        
        <p className="text-red-500 text-lg font-medium mb-8">
          Esta ação é irreversível! Todos os seus dados serão permanentemente removidos.
        </p>

        <div className="border-t border-gray-700 my-8"></div>

        <Link href="/" className="w-full max-w-xs mx-auto block">
          <button 
            onClick={handleDeleteAccount}
            className="w-full bg-red-600 text-white py-3 px-6 rounded-lg hover:bg-red-700 transition-colors font-medium"
          >
            Confirmar Exclusão
          </button>
        </Link>

        <Link 
          href="/pagina_perfil" 
          className="mt-6 text-gray-400 hover:text-red-500 transition-colors block"
        >
          Cancelar
        </Link>
      </div>
    </main>
  );
};

export default DeleteAccountScreen;