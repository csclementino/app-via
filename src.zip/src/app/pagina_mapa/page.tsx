'use client'

import React from 'react';
import Navegacao from '@/components/barra_navegacao/page';

const PaginaMapa = () => {
  return (
    <div className="flex flex-col min-h-screen">
      {/*Espaço para o mapa*/}
      <Navegacao />
    </div>
  );
};

export default PaginaMapa;