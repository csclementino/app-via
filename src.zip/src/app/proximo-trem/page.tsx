// app/proximo-trem/page.tsx

'use client';
import Link from 'next/link';
import { ProxTremHeader } from '@/components/ProxTremHeader/page';
import Navegacao from '@/components/barra_navegacao/page';
import linhasJson from '@/data/linhas_metro.json';

export default function ProximoTremPage() {
  const linhas = Object.entries(linhasJson).map(([slug, dados]) => ({
    slug,
    ...dados,
  }));

  return (
    <div className="min-h-screen mb-40">
      <ProxTremHeader />
      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold text-white mb-8">Em qual linha você está?</h1>
        
        <div className="space-y-4">
          {linhas.map((linha) => (
            <Link
              key={linha.slug}
              href={{
                pathname: `/proximo-trem/${linha.slug}`,
                query: {
                  id: linha.id,
                  conce: linha.conce
                }
              }}
              className="flex items-center justify-between rounded-xl border border-neutral-600"
            >
              <div 
                className="w-12 h-12 flex items-center rounded-l-xl justify-center text-white font-bold text-xl"
                style={{ backgroundColor: '#444' }} // Cor da linha, se quiser
              >
                {linha.id}
              </div>
              <div className="flex-1 px-4">
                <h2 className="text-lg font-semibold text-white">{linha.nome}</h2>
              </div>
              <div className="w-8 h-8 rounded-full flex items-center justify-center text-white">
                &gt;
              </div>
            </Link>
          ))}
        </div>
      </main>
      <Navegacao />
    </div>
  );
}
