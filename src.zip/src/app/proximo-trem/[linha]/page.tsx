'use client';

import { useParams } from 'next/navigation';
import linhasData from '@/data/linhas_metro.json';
import Link from 'next/link';

export default function LinhaPage() {
  const params = useParams();
  const slug = params.linha as string; // Ex: linha4, linha5...

  const linha = linhasData[slug as keyof typeof linhasData];

  if (!linha) {
    return <p className="text-white p-4">Linha não encontrada.</p>;
  }

  return (
    <div className="min-h-screen p-6">
      <h1 className="text-2xl text-white font-bold mb-4">{linha.nome}</h1>
      <p className="text-white mb-4">Selecione uma estação da {linha.nome}:</p>

      <div className="space-y-3">
        {linha.estacoes.map((estacao, index) => (
          <Link
            key={index}
            href={{
              pathname: `/proximo-trem/${slug}/${estacao.sigla}`,
              query: {
                id: linha.id,
                conce: linha.conce,
              },
            }}
            className="block bg-neutral-800 p-4 rounded-xl text-white hover:bg-neutral-700 transition"
          >
            {estacao.nome}
          </Link>
        ))}
      </div>
    </div>
  );
}
