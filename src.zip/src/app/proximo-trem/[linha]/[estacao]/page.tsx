'use client';
import { useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import Navegacao from '@/components/barra_navegacao/page';

interface TremData {
  track: string;
  station: string;
  direction: string;
  expectedArrivalTime: string;
}

export default function EstacaoPage() {
  const { estacao } = useParams();
  const searchParams = useSearchParams();

  const id = searchParams.get('id');
  const conce = searchParams.get('conce');

  const [dados, setDados] = useState<TremData[]>([]);
  const [ultimaAtualizacao, setUltimaAtualizacao] = useState('');
  const [sentidoSelecionado, setSentidoSelecionado] = useState(0);

  const alternarSentido = () => {
    setSentidoSelecionado((prev) => (prev === 0 ? 1 : 0));
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await fetch(`http://127.0.0.1:8000/api/next-train/${conce}/${id}/${estacao}`);
        const json = await res.json();

        if (json?.Status && json?.Data) {
          setDados(json.Data);
          setUltimaAtualizacao(json.ultima_atualizacao || '');
        }
      } catch (error) {
        console.error('Erro ao buscar dados da API:', error);
      }
    };

    if (id && conce && estacao) fetchData();
  }, [id, conce, estacao]);


  const direcoesValidas = Array.from(
    new Set(
      dados
        .filter((d) => d.expectedArrivalTime)
        .map((d) => d.direction)
    )
  );

  const dadosFiltrados = dados.filter(
    (d) => d.direction === direcoesValidas[sentidoSelecionado] && d.expectedArrivalTime
  );

  const horariosSentido = dadosFiltrados.map((item) =>
    new Date(item.expectedArrivalTime).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit',
    })
  );

  return (
    <div className="min-h-screen">
      <header className="bg-gradient-to-b from-teal-300 to-cyan-600 text-white py-12 px-4">
        <div className="flex flex-row items-center justify-around max-w-4xl mx-auto text-left ml-2 mt-2">
          <div>
            <h1 className="text-3xl font-bold mb-3">Próximo Trem</h1>
            <p className="text-lg opacity-90">
              Saiba quanto tempo falta para o próximo trem chegar
            </p>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto space-y-8 p-6 text-white">
        <div className="flex items-center justify-between">
          <p className="text-lg text-left">
            O próximo trem sentido{' '}
            {direcoesValidas[sentidoSelecionado] || ''} chega às:
          </p>

          {direcoesValidas.length > 1 && (
            <button onClick={alternarSentido} className="p-2">
              <img
                src="/icone_alternar.png"
                alt="Alternar sentido"
                className="w-12 h-12"
              />
            </button>
          )}
        </div>

        <div className="rounded-2xl p-8">
          <div className="grid grid-cols-4 gap-4">
            {horariosSentido.map((t, i) => {
              const digitos = t.replace(':', '').split('');
              return digitos.map((digito, j) => (
                <div
                  key={`${i}-${j}`}
                  className="text-center p-4 bg-neutral-700 shadow-md rounded-xl"
                >
                  <span className="text-3xl font-bold text-teal-400">{digito}</span>
                </div>
              ));
            })}

            {horariosSentido.length === 0 && (
              <div className="col-span-4 text-center py-4 text-gray-400">
                Nenhum horário disponível
              </div>
            )}
          </div>
        </div>

        <div className="text-sm">ÚLTIMA ATUALIZAÇÃO: {ultimaAtualizacao}</div>

        <div className="bg-neutral-600 rounded-xl p-4 text-white">
          <p className="text-neutral-300">
            Viu algo suspeito ou desconfortável? Use a guia{' '}
            <Link href="/reportes" className="text-blue-400 hover:underline">
              Reportes
            </Link>
          </p>
        </div>
      </div>
      <Navegacao />
    </div>
  );
}
