// app/pesquisa/page.tsx
'use client'

import Link from 'next/link';
import Navegacao from '@/components/barra_navegacao/page';

const SearchPage = () => {
  return (
    <main className="min-h-screen flex flex-col items-center justify-center p-8 bg-gradient-to-b from-[#2d2d2d] via-[#1a1a1a] via-50% to-[#000000]">
      <div className="max-w-3xl mx-auto p-4 text-center">
        <img 
          src="/em-construcao.png" 
          alt="Em construção" 
          className="w-32 h-32 mx-auto mb-6 filter invert"
        />
        <h1 className="text-3xl font-bold text-blue-500 mb-4">
          Funcionalidade em Desenvolvimento
        </h1>
        <p className="text-gray-300 text-lg leading-relaxed mb-8">
          Nossa equipe está trabalhando para implementar o sistema de pesquisa completo
          integrado com nossas APIs. Esta funcionalidade estará disponível em breve!
        </p>
        <Link 
          href="/tela_principal" 
          className="inline-block px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          Voltar para a página inicial
        </Link>
      </div>
      <Navegacao />
    </main>
  );
};

export default SearchPage;