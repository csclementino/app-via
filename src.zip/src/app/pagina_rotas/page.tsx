// app/tela_principal/page.tsx
'use client'

import React from 'react';
import Header_Principal from '@/components/header_principal/page';
import Navegacao from '@/components/barra_navegacao/page';
import MainContent from '@/components/conteudo_rotas/page';

const MainPage = () => {
  return (
    <div className="flex flex-col min-h-screen">
      <div className="flex-1 flex flex-col">
        <Header_Principal />
        <div className="relative pb-20 mb-16 flex-1">
          <MainContent />
        </div>
      </div>

      <Navegacao />
    </div>
  );
};

export default MainPage;