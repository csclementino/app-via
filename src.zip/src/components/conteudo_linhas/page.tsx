
'use client';
import React, { useEffect, useState } from 'react';
import BotaoVoltar from '@/components/BotaoVoltar/page';

interface LinhaStatus {
  id: number;
  nome: string;
  cor: string;
  status: 'Operação Normal' | 'Velocidade Reduzida';
}

const LinhasStatus: React.FC = () => {
  const [horaAtualizado, setHoraAtualizado] = useState<string>('');
  const [linhas, setLinhas] = useState<LinhaStatus[]>([
    {
      id: 1,
      nome: 'Azul',
      cor: 'bg-blue-600',
      status: 'Operação Normal',
    },
    {
      id: 2,
      nome: 'Verde',
      cor: 'bg-green-600',
      status: 'Operação Normal',
    },
    {
      id: 3,
      nome: 'Vermelha',
      cor: 'bg-red-600',
      status: 'Operação Normal',
    },
    {
      id: 4,
      nome: 'Amarela',
      cor: 'bg-yellow-500',
      status: 'Operação Normal',
    },
    {
      id: 5,
      nome: 'Lilás',
      cor: 'bg-purple-600',
      status: 'Operação Normal'
    },
    {
      id: 7,
      nome: 'Rubi',
      cor: 'bg-pink-800',
      status: 'Operação Normal'
    },
    {
      id: 8,
      nome: 'Diamante',
      cor: 'bg-gray-300',
      status: 'Operação Normal'
    },
    {
      id: 9,
      nome: 'Esmeralda',
      cor: 'bg-emerald-400',
      status: 'Operação Normal'
    },
    {
      id: 10,
      nome: 'Turquesa',
      cor: 'bg-cyan-400',
      status: 'Operação Normal'
    },
    {
      id: 11,
      nome: 'Coral',
      cor: 'bg-rose-600',
      status: 'Operação Normal', // Exemplo de linha com intercorrência
    },
    {
      id: 12,
      nome: 'Safira',
      cor: 'bg-indigo-700',
      status: 'Operação Normal'
    },
    {
      id: 13,
      nome: 'Jade',
      cor: 'bg-teal-400',
      status: 'Operação Normal'
    },
    {
      id: 15,
      nome: 'Prata',
      cor: 'bg-slate-400',
      status: 'Operação Normal'
    },
  ]);

  useEffect(() => {
    const fetchDados = async () => {
      try {
        const response = await fetch('https://ccrviafast-production.up.railway.app/api/linhas');
        const data = await response.json();
        
        const atualizado = new Date().toLocaleTimeString('pt-BR', {
          hour: '2-digit',
          minute: '2-digit'
        });
        
        setLinhas(prev => prev.map(linha => ({
          ...linha,
          status: data[`linha${linha.id}`]?.status || 'Operação Normal'
        })));
        
        setHoraAtualizado(atualizado);
      } catch (error) {
        console.error('Erro ao buscar dados:', error);
      }
    };

    fetchDados();
  }, []);

  return (
    <div className="p-5 max-w-4xl mx-auto">
      <BotaoVoltar />
      <header className="text-center mb-8">
        <h1 className="text-2xl font-bold text-white mb-2">Operação das Linhas</h1>
        <p className="text-gray-300">Veja em tempo real como está o funcionamento das linhas</p>
      </header>

      <div>
        {linhas.map((linha, index) => (
          <div 
            key={linha.id}
            className={`p-4 ${index !== linhas.length - 1 ? 'border-b border-gray-600' : ''}`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                {/* Quadrado colorido com número */}
                <div className={`${linha.cor} w-8 h-8 flex items-center justify-center`}>
                  <span className="text-white font-bold">{linha.id}</span>
                </div>
                <h2 className="text-white text-lg">{linha.nome}</h2>
              </div>

              {/* Status */}
              <div className={`px-2 py-1 rounded-sm ${
                linha.status === 'Operação Normal' 
                  ? 'bg-green-700 text-white' 
                  : 'bg-yellow-600 text-white'
              }`}>
                {linha.status}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LinhasStatus;