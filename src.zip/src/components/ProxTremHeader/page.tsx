'use client';
import React from 'react';
import BotaoVoltar from '@/components/BotaoVoltar/page';
import Image from 'next/image';

export const ProxTremHeader = () => {
  return (
    <header className="bg-gradient-to-b from-teal-300 to-cyan-600 text-white py-12 px-4">
      <BotaoVoltar />
      <div className="flex flex-row items-center justify-around max-w-4xl mx-auto text-left ml-2 mt-2">
        <div>
          <h1 className="text-3xl font-bold mb-3">Próximo Trem</h1>
          <p className="text-lg opacity-90">
            Saiba quanto tempo falta  para o próximo trem chegar 
          </p>
        </div>
        <Image width={80} height={80} src="/proxtrem.png" alt="Reportes" />
      </div>
    </header>
  );
};