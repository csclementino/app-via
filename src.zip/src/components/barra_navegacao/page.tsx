import React from 'react';
import Link from 'next/link';

const Navegacao: React.FC = () => {
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-[#242424] shadow-lg py-2 flex justify-around items-center h-15 rounded-t-4xl">
      <Link href="/tela_principal" className="flex flex-col items-center justify-center text-slate-400 transition-all p-2 gap-1 flex-1 max-w-20 hover:text-blue-500">
        <img src="/icone_menu.png" className="w-6 h-6 object-contain" alt="Home"/>
      </Link>
      
      <Link href="/pagina_mapa" className="flex flex-col items-center justify-center text-slate-400 transition-all p-2 gap-1 flex-1 max-w-20 hover:text-blue-500">
        <img src="/icone_mapa.png" className="w-6 h-6 object-contain" alt="Mapa"/>
      </Link>
      
      <Link href="/pagina_perfil" className="flex flex-col items-center justify-center text-slate-400 transition-all p-2 gap-1 flex-1 max-w-20 hover:text-blue-500">
        <img src="/icone_usuario.png" className="w-6 h-6 object-contain" alt="Perfil"/>
      </Link>
    </nav>
  );
};

export default Navegacao;
