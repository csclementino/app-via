'use client';
import React from 'react';
import BotaoVoltar from '@/components/BotaoVoltar/page';

export const ReportHeader = () => {
  return (
    <header className="bg-gradient-to-b from-orange-400 to-red-600 text-white py-12 px-4">
      <BotaoVoltar />
      <div className="flex flex-row items-center justify-around max-w-4xl mx-auto text-left ml-2 mt-2">
        <div>
          <h1 className="text-3xl font-bold mb-3">Reportes</h1>
          <p className="text-lg opacity-90">
            Use esta área para comunicar situações de emergência ou segurança no metrô
          </p>
        </div>
        <img src="megafone.png" alt="Reportes" />
      </div>
    </header>
  );
};