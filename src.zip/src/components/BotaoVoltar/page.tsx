// components/BotaoVolta.tsx
'use client'

import Link from 'next/link'

const BotaoVoltar = () => {
  return (
    <Link href="/tela_principal">
      <button
        className="absolute top-4 left-2 w-10 h-10 flex items-center justify-center"
        aria-label="Voltar"
      >
        <span className="text-xl font-bold">&lt;</span>
      </button>
    </Link>
  )
}

export default BotaoVoltar