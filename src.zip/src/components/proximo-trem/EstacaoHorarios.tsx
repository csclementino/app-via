'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import BotaoVoltar from '../BotaoVoltar/page';

type LinhaType = {
  slug: string;
  nome: string;
  sentidos: readonly string[];
  estacoes: readonly string[];
};

type HorariosType = {
  [key: string]: {
    [key: string]: number[][];
  };
};

const horarios: HorariosType = {
  '4-amarela': {
    'Luz': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Republica': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Higienopolis': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Paulista': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Oscar Freire': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Fradique Coutinho': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Faria Lima': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Pinheiros': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Butanta': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Sao Paulo Morumbi': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Vila Sonia': [[1, 7, 1, 5], [1, 7, 1, 8]],
  },
  '5-lilas': {
    'Capao Redondo': [],
    'Campo Limpo': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Vila das Belezas': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Giovanni Gronchi': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Santo Amaro': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Largo Treze': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Adolfo Pinheiro': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Alto da Boa Vista': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Borba Gato': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Brooklin': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Campo Belo': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Eucaliptos': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Moema': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'AACD-Servidor': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Hospital Sao Paulo': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Santa Cruz': [[1, 7, 1, 5], [1, 7, 1, 8]],
    'Chacara Klabin': [[1, 7, 1, 5], [1, 7, 1, 8]],
  },
  '8-diamante': {

  },
  '9-esmeralda': {
            'Osasco': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Presidente Altino': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Ceasa': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Vila Lobos Jaguare': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Cidade Universitaria': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Butanta': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Pinheiros': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Hebraica Reboucas': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Cidade Jardim': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Vila Olimpia': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Berrini': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Morumbi': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Granja Julieta': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Santo Amaro': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Jurubatuba': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Autodromo': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Interlagos': [[1, 7, 1, 5], [1, 7, 1, 8]],
            'Grajau': [[1, 7, 1, 5], [1, 7, 1, 8]]
  }
};

export default function EstacaoHorarios({ linha, estacaoSlug }: { linha: LinhaType; estacaoSlug: string }) {
  const [sentidoSelecionado, setSentidoSelecionado] = useState(0);
  const [nomeEstacao, setNomeEstacao] = useState('');

  useEffect(() => {
    const formatarNome = (slug: string) => {
      return slug
        .replace(/-/g, ' ')
        .replace(/(^\w|\s\w)/g, m => m.toUpperCase());
    };
    setNomeEstacao(formatarNome(estacaoSlug));
  }, [estacaoSlug]);

  const horariosEstacao = horarios[linha.slug]?.[nomeEstacao] || [[], []];
  const horariosSentido = horariosEstacao[sentidoSelecionado] || [];

  // Função para alternar entre os sentidos
  const alternarSentido = () => {
    setSentidoSelecionado(prev => (prev === 0 ? 1 : 0));
  };

  return (
    <div className="min-h-screen">
      <header className="bg-gradient-to-b from-teal-300 to-cyan-600 text-white py-12 px-4">
        <BotaoVoltar />
        <div className="flex flex-row items-center justify-around max-w-4xl mx-auto text-left ml-2 mt-2">
          <div>
            <h1 className="text-3xl font-bold mb-3">Próximo Trem</h1>
            <p className="text-lg opacity-90">
              Saiba quanto tempo falta para o próximo trem chegar
            </p>
          </div>
        </div>
      </header>
      
      <div className="max-w-4xl mx-auto space-y-8 p-6">
        <div className="flex items-center justify-between">
          <p className="text-lg text-left">
            O próximo trem sentido {linha.sentidos[sentidoSelecionado]?.split('→')[1]?.trim() || 'Não disponível'} chega às:
          </p>
          
          {/* Botão de alternância */}
          <button
            onClick={alternarSentido}
            className="p-2"
          >
            <img 
              src="/icone_alternar.png" 
              alt="Alternar sentido" 
              className="w-12 h-12"
            />
          </button>
        </div>

        {/* Restante do código mantido igual */}
        <div className="rounded-2xl p-8">
          <div className="flex justify-between items-start mb-6">
            <h2 className="text-xl font-semibold text-white">{nomeEstacao}</h2>
          </div>

          <div className="grid grid-cols-4 gap-4">
            {horariosSentido.map((t, i) => (
              <div key={i} className="text-center p-4 bg-neutral-700 shadow-md rounded-xl">
                <span className="text-3xl font-bold text-teal-400">{t}</span>
              </div>
            ))}
            {horariosSentido.length === 0 && (
              <div className="col-span-4 text-center py-4 text-gray-400">
                Nenhum horário disponível
              </div>
            )}
          </div>
        </div>

        <div className="text-sm">
          ÚLTIMA ATUALIZAÇÃO: 05/05/2025 17:34
        </div>

        <div className="bg-neutral-600 rounded-xl p-4 text-white">
          <p className="text-neutral-300">
            Viu algo suspeito ou desconfortável? Use a guia {' '}
            <Link href="/reportes" className="text-blue-400 hover:underline">
              Reportes
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}