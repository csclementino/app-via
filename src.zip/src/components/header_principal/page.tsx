import React from 'react';

const Header_Principal = () => {
  return (
    <header className="relative h-[40vh] overflow-hidden my-[8vh] mx-[2vh] rounded-[4vh] shadow-[0vh_1vh_1vh_#1a1a1a]">
      <div className="absolute top-0 left-0 w-screen h-[50vh]">
        <img 
          src="banner_tela_principal.png" 
          className="w-full h-full object-cover"
          alt="Banner principal"
        />
        <div className="absolute inset-0 bg-black/40"></div>
      </div>
      
      <div className="absolute z-10 flex flex-col items-start text-left gap-[1vh] h-screen py-[20vh] px-[2vh]">
        <div>
          <h1 className="text-[3vh] font-bold text-white">Olá, Carlos!</h1>
        </div>
        <div>
          <p className="text-[2.5vh] font-light text-white w-[60%]">
            Pronto para uma viagem tranquila com a gente?
          </p>
        </div>
      </div>
    </header>
  );
};

export default Header_Principal;