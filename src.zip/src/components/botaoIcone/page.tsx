import React from 'react';

interface BotaoIconeProps {
  children: React.ReactNode;
  icone: string;
  onClick?: () => void;
}

export const BotaoIcone = ({ children, icone, onClick }: BotaoIconeProps) => {
  return (
    <button 
      className="flex flex-col items-center gap-[2vh] p-[4vh] w-full border-2 border-white rounded-[6vh] cursor-pointer transition-colors duration-200 hover:bg-[#616161]"
      onClick={onClick}
    >
      <span className="flex items-center">
        <img 
          src={icone} 
          alt="Ícone" 
          className="w-6 h-6 object-contain"
        />
      </span>
      <span className="text-inherit">{children}</span>
    </button>
  );
};