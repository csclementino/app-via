import React, { useState, useRef } from 'react';

interface Parceiro {
    caminho: string;
    titulo: string;
    texto: string;
    link: string;
}

interface ParceirosProps {
    titulo: string;
    parceiros: Parceiro[];
}

export const Parceiros = ({ titulo, parceiros }: ParceirosProps) => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const carouselRef = useRef<HTMLDivElement>(null);

    const handleNext = () => {
        if (carouselRef.current) {
            const newSlide = currentSlide + 1;
            carouselRef.current.scrollLeft += carouselRef.current.offsetWidth;
            setCurrentSlide(newSlide);
        }
    };

    const handlePrev = () => {
        if (carouselRef.current) {
            const newSlide = currentSlide - 1;
            carouselRef.current.scrollLeft -= carouselRef.current.offsetWidth;
            setCurrentSlide(newSlide);
        }
    };

    return (
        <div className="relative px-16 mt-[4vh]">
            <h2 className="text-white text-2xl text-left mb-10 relative">{titulo}</h2>

            <div
                ref={carouselRef}
                className="flex overflow-x-hidden scroll-smooth  bg-[#323232] rounded-[5vh] snap-x snap-mandatory"
            >
                {parceiros.map((parceiro, index) => (
                    <div
                        key={index}
                        className="min-w-full flex-shrink-0 snap-align-start transition-transform duration-300"
                    >
                        <div className="flex items-center text-left">
                            <img
                                src={parceiro.caminho}
                                alt={parceiro.titulo}
                                className="w-auto h-full object-cover"
                            />
                            <div className="flex-1 text-white ml-5">
                                <h3 className="text-md">{parceiro.titulo}</h3>
                                <p className="text-xs text-[#ccc] whitespace-pre-line">
                                    {parceiro.texto}
                                </p>
                                <a
                                    href={parceiro.link}
                                    className="text-[#00ff88] text-xs font-medium hover:opacity-80 transition-opacity"
                                >
                                    Saiba mais →
                                </a>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <button
                className={`absolute top-2/3 -translate-y-1/3 left-5 border-none text-white text-3xl w-12 h-12 rounded-full cursor-pointer transition-colors ${currentSlide === 0 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-white/20'
                    }`}
                onClick={handlePrev}
                disabled={currentSlide === 0}
            >
                ‹
            </button>
            <button
                className={`absolute top-2/3 -translate-y-1/3 right-5 border-none text-white text-3xl w-12 h-12 rounded-full cursor-pointer transition-colors ${currentSlide === parceiros.length - 1 ? 'opacity-30 cursor-not-allowed' : 'hover:bg-white/20'
                    }`}
                onClick={handleNext}
                disabled={currentSlide === parceiros.length - 1}
            >
                ›
            </button>
        </div>
    );
};