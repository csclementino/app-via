'use client'

import React from 'react';
import { useRouter } from 'next/navigation';
import { BotaoIcone } from '@/components/botaoIcone/page';

interface AcessoRapidoProps {
    titulo: string;
    botoes: Array<{
      texto: string;
      icone: string;
      caminho: string; 
    }>;
}

export const AcessoRapido = ({ titulo, botoes }: AcessoRapidoProps) => {
  const router = useRouter();

  return (
    <div className="text-left px-[2vw]">
      <h2 className="mb-[6vh] text-[2rem]">{titulo}</h2>
      <div className="grid grid-cols-3 justify-around gap-[8vh] px-[2vw]">
        {botoes.map((botao, index) => (
          <BotaoIcone
            key={index}
            icone={botao.icone}
            onClick={() => router.push(botao.caminho)}
          >
            {botao.texto}
          </BotaoIcone>
        ))}
      </div>
    </div>
  );
};