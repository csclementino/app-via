'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import BotaoVoltar from '@/components/BotaoVoltar/page';
import Image from 'next/image';

type LineStations = {
    [key: string]: string[];
};

type CadastroFormProps = {
    tipoReporte: string;
};

// Mapeamento de slugs para nomes formatados e ícones
const CATEGORY_DATA: { [key: string]: { name: string; icon: string } } = {
    'assedio': { name: 'Assédio', icon: '/assedio.png' },
    'racismo': { name: 'Racismo', icon: '/racismo.png' },
    'roubo': { name: 'Roubo', icon: '/roubo.png' },
    'vandalismo': { name: 'Vandalismo', icon: '/vandalismo.png' },
    'violencia': { name: 'Violência', icon: '/violencia.png' },
    'venda-ilegal': { name: 'Venda Ilegal', icon: '/vendedor.png' }
};

export const CadastroReporteForm = ({ tipoReporte }: CadastroFormProps) => {
    const [selectedLine, setSelectedLine] = useState('');
    const [stations, setStations] = useState<string[]>([]);
    const [selectedStation, setSelectedStation] = useState('');
    const [date, setDate] = useState('');
    const [time, setTime] = useState('');
    const [details, setDetails] = useState('');

    const lines = ['Linha 4', 'Linha 5', 'Linha 8', 'Linha 9'];
    const lineStations: LineStations = {
        'Linha 4': ['Paulista', 'Faria Lima', 'Pinheiros', 'Butantã'],
        'Linha 5': ['Chácara Klabin', 'Santa Cruz', 'Hospital São Paulo', 'Capão Redondo'],
        'Linha 8': ['Júlio Prestes', 'Osasco', 'Presidente Altino', 'Carapicuíba'],
        'Linha 9': ['Osasco', 'Morumbi', 'Vila Lobos', 'Cidade Jardim']
    };

    useEffect(() => {
        if (selectedLine) {
            setStations(lineStations[selectedLine]);
            setSelectedStation('');
        }
    }, [selectedLine]);

    // Obter dados formatados
    const getCategoryData = () => {
        return CATEGORY_DATA[tipoReporte] || { name: 'Reporte', icon: '' };
    };

    const { name: categoryName, icon: categoryIcon } = getCategoryData();

    return (
        <div className="min-h-screen">
            <main className="max-w-4xl mx-auto px-4 py-8">
                <section className="mb-12">
                    <BotaoVoltar />
                    <h1 className="text-2xl font-semibold text-white mb-6">
                        Cadastro de Reporte
                    </h1>

                    <div className=" p-6 space-y-6">
                        {/* Tipo de Reporte com Ícone */}
                        <div className="bg-teal-500 p-4 rounded-2xl text-white">
                            <div className="flex justify-between text-left items-center">
                                <div>
                                    <h2 className="text-xl font-medium mb-2">Tipo de Reporte</h2>
                                    <p className="text-lg font-semibold">{categoryName}</p>
                                </div>
                                {categoryIcon && (
                                    <Image
                                        src={categoryIcon}
                                        alt="Ícone do Reporte"
                                        width={60}
                                        height={60}
                                        className="filter invert brightness-0"
                                    />
                                )}
                            </div>
                        </div>

                        {/* Campos do formulário */}
                        <div>
                            <h2 className="text-xl font-medium text-white mb-4">Selecione a linha</h2>
                            <select
                                className="w-full bg-neutral-600 border border-neutral-500 p-4 rounded-lg text-white"
                                value={selectedLine}
                                onChange={(e) => setSelectedLine(e.target.value)}
                            >
                                <option value="" className="bg-neutral-700">Selecione uma linha</option>
                                {lines.map((line) => (
                                    <option key={line} value={line} className="bg-neutral-600">{line}</option>
                                ))}
                            </select>
                        </div>

                        <div>
                            <h2 className="text-xl font-medium text-white mb-4">Selecione a estação</h2>
                            <select
                                className="w-full bg-neutral-600 border border-neutral-500 p-4 rounded-lg text-white"
                                value={selectedStation}
                                onChange={(e) => setSelectedStation(e.target.value)}
                                disabled={!selectedLine}
                            >
                                <option value="" className="bg-neutral-700">Selecione uma estação</option>
                                {stations.map((station) => (
                                    <option key={station} value={station} className="bg-neutral-600">{station}</option>
                                ))}
                            </select>
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <h2 className="text-xl font-medium text-white mb-4">Data</h2>
                                <input
                                    type="date"
                                    className="w-full border p-4 rounded-lg text-white"
                                    value={date}
                                    onChange={(e) => setDate(e.target.value)}
                                />
                            </div>
                            <div>
                                <h2 className="text-xl font-medium text-white mb-4">Hora</h2>
                                <input
                                    type="time"
                                    className="w-full border p-4 rounded-lg text-white"
                                    value={time}
                                    onChange={(e) => setTime(e.target.value)}
                                />
                            </div>
                        </div>

                        <div>
                            <h2 className="text-xl font-medium text-white mb-4">
                                Dê mais detalhes sobre o ocorrido...
                            </h2>
                            <textarea
                                className="w-full border p-4 rounded-lg text-white h-32"
                                value={details}
                                onChange={(e) => setDetails(e.target.value)}
                            />
                        </div>

                        <button
                            type="button"
                            onClick={() => {
                                const newReporte = {
                                    id: Date.now().toString(),
                                    tipo: categoryName,
                                    linha: selectedLine,
                                    data: date,
                                    hora: time,
                                    estacao: selectedStation,
                                    descricao: details, // Adicione esta linha
                                    status: 'pendente' as const
                                };

                                const existingReportes = JSON.parse(localStorage.getItem('reportes') || '[]');
                                localStorage.setItem('reportes', JSON.stringify([...existingReportes, newReporte]));
                                window.location.href = '/meus_reportes';
                            }}
                            className="w-full bg-green-500 text-white py-4 rounded-lg hover:bg-green-600 transition-colors"
                        >
                            Enviar Reporte ✅
                        </button>
                    </div>
                </section>
            </main>
        </div>
    );
};