export type Estacao = {
  readonly nome: string;
  readonly sigla: string;
};

export type Linha = {
  readonly numero: number;
  readonly slug: string;
  readonly nome: string;
  readonly cor: string;
  readonly operadora: string;
  readonly estacoes: readonly Estacao[];
  readonly sentidos: readonly string[];
};